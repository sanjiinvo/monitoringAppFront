const fetchSomeData= (par)=> {


    switch (key) {
        case value:
            
            break;
    
        default:
            break;
    }

}