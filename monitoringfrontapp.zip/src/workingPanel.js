


const WorkingPanel = () =>{


    return(
        <div>
            <h2>
                Working panel
            </h2>
        </div>
    )
}

export default WorkingPanel